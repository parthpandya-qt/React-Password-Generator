import { useRef, useCallback, useEffect, useState } from 'react';

function App() {
  const [length, setLength] = useState(8);
  const [noAllowed, setNoAllowed] = useState(false);
  const [charAllowed, setCharAllowed] = useState(false);
  const [password, setPassword] = useState('');

  const passwordRef = useRef(null);
  


  const generatePassword = useCallback(() => {
    let str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if (noAllowed) {
      str += "0123456789";
    }
    if (charAllowed) {
      str += "!@#$%^&*()_+[]{}|";
    }
    let pass = "";
    for (let i = 0; i < length; i++) { // ✅ fixed: array.length -> length
      pass += str.charAt(Math.floor(Math.random() * str.length ));
    }
    setPassword(pass);
  }, [length, noAllowed, charAllowed,setPassword]); 
 
 
 
  const copytoClipboard = useCallback(() => {
    passwordRef.current.select();
    passwordRef.current.setSelectionRange(0, 10); // For mobile devices
    window.navigator.clipboard.writeText(password)},
    [password]);


  useEffect(() => {
  generatePassword();
  }, [length, noAllowed, charAllowed, generatePassword]);
  return (
    <>
      <div className="w-full max-w-md mx-auto rounded-lg shadow-md px-4 py-3 my-8 bg-gray-700 text-orange-500">
        <h1 className='text-white text-center'>Password Generator</h1>

        <div className='flex shadow rounded-lg bg-gray-800 p-4 mb-4'>
          <input
            type="text"
            value={password}
            className="outline-none w-full py-1 px-3"
            placeholder="Password"
            readOnly
            ref={passwordRef}
          />
          <button onClick={copytoClipboard}
            className="outline-none bg-blue-700 text-white px-3 py-0.5 shrink-0 rounded-lg ml-2"
          >
            copy
          </button>
        </div>

        <div className='flex text-sm gap-x-2'>
          <div className='flex items-center gap-x-1'>
            <input
              type="range"
              min={6}
              max={100}
              value={length}
              className='cursor-pointer'
              onChange={(event) => setLength(Number(event.target.value))} 
            />
            <label>Length: {length}</label>
          </div>

          <div className='flex items-center gap-x-1'>
            <input
              type="checkbox"
              defaultChecked={noAllowed}
              id="numberInput"
              onChange={() => {
                setNoAllowed((prev) => !prev); 
              }}

            />
            <label htmlFor="numberInput">Numbers</label>
          </div>
           <div className='flex items-center gap-x-1'>
            <input
              type="checkbox"
              defaultChecked={charAllowed}
              id="numberInput"
              onChange={() => {
                setCharAllowed((prev) => !prev); 
              }}

            />
            <label htmlFor="numberInput">Characters</label>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
